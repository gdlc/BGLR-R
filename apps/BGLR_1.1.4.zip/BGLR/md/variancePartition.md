# Methods for estimating the contribution of DNA segments to genetic variance

**Arabidopsis data**
```R
 load("Atwell2010_Arabidopsis_199Samples_215908SNPs_coded_0_2_BEAGLE_TAIR9_inclDelitions.Rdata")
```

```R
 
```
